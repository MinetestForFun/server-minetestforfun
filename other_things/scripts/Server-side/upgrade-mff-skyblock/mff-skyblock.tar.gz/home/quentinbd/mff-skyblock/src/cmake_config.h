// Filled in by the build system

#ifndef CMAKE_CONFIG_H
#define CMAKE_CONFIG_H

#define PROJECT_NAME "minetest"
#define PROJECT_NAME_C "Minetest"
#define VERSION_MAJOR 0
#define VERSION_MINOR 4
#define VERSION_PATCH 13
#define VERSION_EXTRA ""
#define VERSION_STRING "0.4.13"
#define PRODUCT_VERSION_STRING "0.4"
#define STATIC_SHAREDIR "."
#define BUILD_TYPE "Release"
#define RUN_IN_PLACE 1
#define USE_GETTEXT 1
#define USE_CURL 1
#define USE_SOUND 0
#define USE_FREETYPE 1
#define USE_LEVELDB 1
#define USE_LUAJIT 1
#define USE_SPATIAL 0
#define USE_SYSTEM_GMP 1
#define USE_REDIS 1
#define HAVE_ENDIAN_H 1

#endif

