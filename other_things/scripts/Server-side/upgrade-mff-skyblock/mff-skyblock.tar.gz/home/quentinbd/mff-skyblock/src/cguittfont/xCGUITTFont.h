// A wrapper header to avoid hack with gcc and modifying
// the CGUITTFont files.

#include <algorithm>
#include <stddef.h>
#include "irrUString.h"
#include "CGUITTFont.h"
