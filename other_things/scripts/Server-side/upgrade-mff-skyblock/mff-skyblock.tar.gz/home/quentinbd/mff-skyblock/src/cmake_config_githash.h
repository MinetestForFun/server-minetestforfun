// Filled in by the build system
// Separated from cmake_config.h to avoid excessive rebuilds on every commit

#ifndef CMAKE_CONFIG_GITHASH_H
#define CMAKE_CONFIG_GITHASH_H

#define VERSION_GITHASH "0.4.13"

#endif

