// A wrapper source file to avoid hack with gcc and modifying
// the CGUITTFont files.

#include "xCGUITTFont.h"
#include "CGUITTFont.cpp"
